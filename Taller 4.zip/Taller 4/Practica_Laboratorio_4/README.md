# Práctica de Laboratorio 4 - Fundamentos de Programación

Sistema de registro y facturación para un taller mecánico desarrollado en C#.

## Estructura
- FacturacionTaller: biblioteca independiente.
- ModuloTaller: cálculos de tarifas, descuento, IGV y total.
- ModuloArchivo: guardar, buscar y listar atenciones.
- TallerMecanico: programa principal con menú.

## Ejecutar
1. Abrir `Practica_Laboratorio_4.sln` en Visual Studio 2022.
2. Establecer `TallerMecanico` como proyecto de inicio.
3. Ejecutar con `Ctrl + F5`.

Requiere .NET 8.
