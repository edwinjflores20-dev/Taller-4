using FacturacionTaller;

namespace TallerMecanico
{
    internal class Program
    {
        static void Main()
        {
            int opcion = 0;

            do
            {
                MostrarMenu();

                try
                {
                    Console.Write("Seleccione una opción: ");
                    opcion = int.Parse(Console.ReadLine() ?? "0");

                    switch (opcion)
                    {
                        case 1:
                            RegistrarAtencion();
                            break;
                        case 2:
                            Console.Write("Ingrese la placa: ");
                            string placa = Console.ReadLine() ?? "";
                            ModuloArchivo.BuscarAtencion(placa);
                            break;
                        case 3:
                            ModuloArchivo.ListarTodasLasAtenciones();
                            break;
                        case 4:
                            Console.WriteLine("Gracias por utilizar el sistema.");
                            break;
                        default:
                            Console.WriteLine("Opción no válida.");
                            break;
                    }
                }
                catch (FormatException)
                {
                    Console.WriteLine("Debe ingresar un número válido.");
                }
                catch (IOException ex)
                {
                    Console.WriteLine("Error al acceder al archivo: " + ex.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }

                if (opcion != 4)
                {
                    Console.WriteLine("\nPresione ENTER para continuar...");
                    Console.ReadLine();
                }

            } while (opcion != 4);
        }

        static void MostrarMenu()
        {
            Console.Clear();
            Console.WriteLine("==================================");
            Console.WriteLine("     SISTEMA DE TALLER MECÁNICO");
            Console.WriteLine("==================================");
            Console.WriteLine("1. Registrar atención");
            Console.WriteLine("2. Buscar atención por placa");
            Console.WriteLine("3. Reporte general");
            Console.WriteLine("4. Salir");
            Console.WriteLine("==================================");
        }

        static void RegistrarAtencion()
        {
            Console.WriteLine("\n--- REGISTRAR ATENCIÓN ---");

            string placa = LeerDato("Placa: ").ToUpper();
            string propietario = LeerDato("Nombre del propietario: ");
            string servicio = LeerDato("Servicio (PREVENTIVO/CORRECTIVO/OTRO): ").ToUpper();
            string frecuente = LeerFrecuencia();

            decimal tarifa = ModuloTaller.ObtenerTarifaBase(servicio);
            decimal descuento = ModuloTaller.CalcularDescuentoCliente(tarifa, frecuente);
            decimal igv = ModuloTaller.CalcularImpuestoIGV(tarifa - descuento);
            decimal total = ModuloTaller.CalcularTotalPagar(tarifa, descuento, igv);

            string fecha = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");

            Console.WriteLine("\n--- RESUMEN DE FACTURA ---");
            Console.WriteLine($"Tarifa base: S/ {tarifa:F2}");
            Console.WriteLine($"Descuento:   S/ {descuento:F2}");
            Console.WriteLine($"IGV (18%):   S/ {igv:F2}");
            Console.WriteLine($"TOTAL:       S/ {total:F2}");

            string registro = ModuloTaller.ConstruirRegistroPipe(
                placa, propietario, servicio, total, fecha);

            ModuloArchivo.GuardarAtencion(registro);
            Console.WriteLine("\nAtención guardada correctamente.");
        }

        static string LeerDato(string mensaje)
        {
            string dato;
            do
            {
                Console.Write(mensaje);
                dato = (Console.ReadLine() ?? "").Trim();

                if (dato == "")
                    Console.WriteLine("Este campo no puede estar vacío.");

            } while (dato == "");

            return dato;
        }

        static string LeerFrecuencia()
        {
            string respuesta;
            do
            {
                respuesta = LeerDato("¿Cliente frecuente? (SI/NO): ").ToUpper();
                if (respuesta != "SI" && respuesta != "NO")
                    Console.WriteLine("Responda SI o NO.");
            } while (respuesta != "SI" && respuesta != "NO");

            return respuesta;
        }
    }
}
