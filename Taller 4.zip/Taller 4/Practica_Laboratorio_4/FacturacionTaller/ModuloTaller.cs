using System.Globalization;

namespace FacturacionTaller
{
    public static class ModuloTaller
    {
        public static decimal ObtenerTarifaBase(string tipoServicio)
        {
            switch (tipoServicio.Trim().ToUpper())
            {
                case "PREVENTIVO": return 180.00m;
                case "CORRECTIVO": return 320.00m;
                default: return 120.00m;
            }
        }

        public static decimal CalcularDescuentoCliente(decimal tarifaBase, string esFrecuente)
        {
            return esFrecuente.Trim().ToUpper() == "SI" ? tarifaBase * 0.15m : 0m;
        }

        public static decimal CalcularImpuestoIGV(decimal tarifaConDescuento)
        {
            return tarifaConDescuento * 0.18m;
        }

        public static decimal CalcularTotalPagar(decimal tarifaBase, decimal descuento, decimal igv)
        {
            return tarifaBase - descuento + igv;
        }

        public static string ConstruirRegistroPipe(
            string placa, string propietario, string tipoServicio, decimal total, string fecha)
        {
            // El registro siempre contiene cinco campos separados por |
            return $"{placa.Trim().ToUpper()}|{propietario.Trim()}|{tipoServicio.Trim().ToUpper()}|" +
                   $"{total.ToString("F2", CultureInfo.InvariantCulture)}|{fecha}";
        }
    }
}
