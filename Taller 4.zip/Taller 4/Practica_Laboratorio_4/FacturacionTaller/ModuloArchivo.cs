using System.Globalization;

namespace FacturacionTaller
{
    public static class ModuloArchivo
    {
        private static readonly string rutaArchivo =
            Path.Combine(AppContext.BaseDirectory, "atenciones.txt");

        public static void GuardarAtencion(string linea)
        {
            File.AppendAllText(rutaArchivo, linea + Environment.NewLine);
        }

        public static void BuscarAtencion(string placaBuscada)
        {
            if (!File.Exists(rutaArchivo))
            {
                Console.WriteLine("No existen atenciones registradas.");
                return;
            }

            bool encontrado = false;

            foreach (string linea in File.ReadAllLines(rutaArchivo))
            {
                string[] datos = linea.Split('|');

                if (datos.Length == 5 &&
                    datos[0].Equals(placaBuscada, StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine(linea);
                    encontrado = true;
                }
            }

            if (!encontrado)
                Console.WriteLine("No se encontraron registros para esa placa.");
        }

        public static void ListarTodasLasAtenciones()
        {
            if (!File.Exists(rutaArchivo))
            {
                Console.WriteLine("No existen atenciones registradas.");
                return;
            }

            decimal totalRecaudado = 0;
            int cantidad = 0;

            Console.WriteLine("\n--- ATENCIONES REGISTRADAS ---");

            foreach (string linea in File.ReadAllLines(rutaArchivo))
            {
                string[] datos = linea.Split('|');

                if (datos.Length == 5)
                {
                    Console.WriteLine(linea);
                    if (decimal.TryParse(datos[3], NumberStyles.Any,
                        CultureInfo.InvariantCulture, out decimal importe))
                    {
                        totalRecaudado += importe;
                        cantidad++;
                    }
                }
            }

            Console.WriteLine("--------------------------------");
            Console.WriteLine($"Cantidad de atenciones: {cantidad}");
            Console.WriteLine($"Total recaudado: S/ {totalRecaudado:F2}");
        }
    }
}
